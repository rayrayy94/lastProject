#ifndef GROCERYTRACKER_H
#define GROCERYTRACKER_H

#include <string>
#include <map>

class GroceryTracker {
public:
    GroceryTracker(const std::string& filename);
    void PrintItemFrequency(const std::string& item);
    void PrintAllFrequencies();
    void PrintHistogram();
    void WriteBackupFile(const std::string& backupFilename);

private:
    std::map<std::string, int> itemFrequency;
    void LoadDataFromFile(const std::string& filename);
};

#endif
