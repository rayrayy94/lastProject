#include <iostream>
#include <string>
#include "GroceryTracker.h"

using namespace std;

int main() {
    GroceryTracker tracker("Text.txt"); // reads from the file
    tracker.WriteBackupFile("frequency.dat"); // write the backup file

    int choice;
    string item;

    do {
        cout << "\nMENU\n";
        cout << "1. Search for item frequency\n";
        cout << "2. Display frequency of all items\n";
        cout << "3. Display histogram of item frequency\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter item name: ";
            cin >> item;
            tracker.PrintItemFrequency(item);
            break;
        case 2:
            tracker.PrintAllFrequencies();
            break;
        case 3:
            tracker.PrintHistogram();
            break;
        case 4:
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid option. Try again.\n";
        }

    } while (choice != 4);

    return 0;
}
