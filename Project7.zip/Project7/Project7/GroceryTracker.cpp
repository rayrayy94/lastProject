#include "GroceryTracker.h"
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;

GroceryTracker::GroceryTracker(const string& filename) {
    LoadDataFromFile(filename);
}

void GroceryTracker::LoadDataFromFile(const string& filename) {
    ifstream inFile(filename);
    string item;

    if (!inFile.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return;
    }

    while (inFile >> item) {
        ++itemFrequency[item];
    }

    inFile.close();
}

void GroceryTracker::PrintItemFrequency(const string& item) {
    if (itemFrequency.count(item)) {
        cout << item << ": " << itemFrequency[item] << endl;
    }
    else {
        cout << item << ": 0" << endl;
    }
}

void GroceryTracker::PrintAllFrequencies() {
    for (const auto& pair : itemFrequency) {
        cout << pair.first << " " << pair.second << endl;
    }
}

void GroceryTracker::PrintHistogram() {
    for (const auto& pair : itemFrequency) {
        cout << setw(15) << left << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            cout << "*";
        }
        cout << endl;
    }
}

void GroceryTracker::WriteBackupFile(const string& backupFilename) {
    ofstream outFile(backupFilename);
    for (const auto& pair : itemFrequency) {
        outFile << pair.first << " " << pair.second << endl;
    }
    outFile.close();
}
